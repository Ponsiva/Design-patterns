package za.ac.cput.AshDesign.creational.abstractfactory;

/**
 * Created by student on 2015/03/08.
 */
public class Mazda extends Vehicle {

    @Override
    public String vehicleFunction()
    {
        return "Mazda drive...";
    }
}
