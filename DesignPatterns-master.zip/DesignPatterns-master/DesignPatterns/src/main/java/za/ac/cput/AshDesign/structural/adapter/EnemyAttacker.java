package za.ac.cput.AshDesign.structural.adapter;

/**
 * Created by student on 2015/03/10.
 */
public interface EnemyAttacker {

    public void fireWeapon();
    public void driveForward();
    public void assignDriver(String driverName);
}
