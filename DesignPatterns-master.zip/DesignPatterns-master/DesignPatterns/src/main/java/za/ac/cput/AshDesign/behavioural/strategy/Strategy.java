package za.ac.cput.AshDesign.behavioural.strategy;

/**
 * Created by student on 2015/03/11.
 */
public interface Strategy {

    boolean checkAge(int age);
}
