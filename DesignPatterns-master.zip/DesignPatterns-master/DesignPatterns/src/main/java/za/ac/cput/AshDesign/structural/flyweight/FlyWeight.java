package za.ac.cput.AshDesign.structural.flyweight;

/**
 * Created by student on 2015/03/09.
 */
public interface FlyWeight {

    public void calculate(int x, int y);

}
