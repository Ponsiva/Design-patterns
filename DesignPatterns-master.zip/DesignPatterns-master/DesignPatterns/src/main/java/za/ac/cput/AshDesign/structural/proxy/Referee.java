package za.ac.cput.AshDesign.structural.proxy;

/**
 * Created by student on 2015/03/09.
 */
public class Referee extends FootballGame {

    public Referee()
    {
        System.out.println("Making sure the game is played fairly");
    }

    public void Refereef()
    {
        System.out.println("Making sure the game is played fairly");
    }
}
