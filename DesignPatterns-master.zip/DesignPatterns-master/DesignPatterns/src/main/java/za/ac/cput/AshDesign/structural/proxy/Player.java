package za.ac.cput.AshDesign.structural.proxy;

/**
 * Created by student on 2015/03/09.
 */
public class Player extends FootballGame {

    String name;

    public Player()
    {

    }
}
