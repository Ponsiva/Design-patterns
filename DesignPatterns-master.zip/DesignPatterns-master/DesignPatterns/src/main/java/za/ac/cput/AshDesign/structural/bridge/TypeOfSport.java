package za.ac.cput.AshDesign.structural.bridge;

/**
 * Created by student on 2015/03/10.
 */
public interface TypeOfSport {

    public int playersInSport();
}
