package za.ac.cput.AshDesign.creational.abstractfactory;

/**
 * Created by student on 2015/03/08.
 */
public class Polo extends Vehicle{

    @Override
    public String vehicleFunction()
    {
        return "Polo drive...";
    }
}
