package za.ac.cput.AshDesign.creational.factorymethod;

/**
 * Created by student on 2015/03/07.
 */
public abstract class Calculator {

    public abstract int calculate(int n1, int n2);
}
