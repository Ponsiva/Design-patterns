package za.ac.cput.AshDesign.behavioural.observer;

/**
 * Created by student on 2015/03/11.
 */
public interface WorkObserver {

    public void doUpdate(int workRate);
}
