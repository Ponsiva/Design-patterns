package za.ac.cput.AshDesign.behavioural.command;

/**
 * Created by student on 2015/03/11.
 */
public class AfternoonClass {

    public void attendAfternoon() {
        System.out.println("Attend afternoon class");
    }
}
