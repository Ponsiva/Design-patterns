package za.ac.cput.AshDesign.creational.prototype;

/**
 * Created by student on 2015/03/09.
 */
public interface Prototype {

    public Prototype doClone();
}
