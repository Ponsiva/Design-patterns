package za.ac.cput.AshDesign.structural.adapter;

/**
 * Created by student on 2015/03/09.
 */
public class Adapter {
}
