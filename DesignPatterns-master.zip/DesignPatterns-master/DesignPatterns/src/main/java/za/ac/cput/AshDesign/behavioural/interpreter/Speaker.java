package za.ac.cput.AshDesign.behavioural.interpreter;

/**
 * Created by student on 2015/03/12.
 */
public interface Speaker {


    public boolean speaker(String context);
}
