package za.ac.cput.AshDesign.creational.abstractfactory;

/**
 * Created by student on 2015/03/08.
 */
public class GarbageTruck extends Vehicle{

    @Override
    public String vehicleFunction()
    {
        return "collects Garbage";
    }
}
