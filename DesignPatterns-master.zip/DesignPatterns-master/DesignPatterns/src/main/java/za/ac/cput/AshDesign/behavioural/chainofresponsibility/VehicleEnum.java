package za.ac.cput.AshDesign.behavioural.chainofresponsibility;

/**
 * Created by student on 2015/03/10.
 */
public enum VehicleEnum {

    BMW, MERCEDES,JEEP,;
}
