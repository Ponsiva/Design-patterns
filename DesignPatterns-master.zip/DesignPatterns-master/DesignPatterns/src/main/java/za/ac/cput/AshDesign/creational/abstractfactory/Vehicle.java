package za.ac.cput.AshDesign.creational.abstractfactory;

/**
 * Created by student on 2015/03/08.
 */
public abstract class Vehicle {

    public abstract String vehicleFunction();
}
