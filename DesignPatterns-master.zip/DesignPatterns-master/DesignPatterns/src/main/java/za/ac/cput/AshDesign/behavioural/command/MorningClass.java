package za.ac.cput.AshDesign.behavioural.command;

/**
 * Created by student on 2015/03/11.
 */
public class MorningClass {

    public void attendMorning() {
        System.out.println("Attend morning class");
    }
}
