package za.ac.cput.AshDesign.behavioural.state;

/**
 * Created by student on 2015/03/11.
 */
public interface MoodState {

    public String sayGreetings();
    public String sayGreetingsBad();
}
