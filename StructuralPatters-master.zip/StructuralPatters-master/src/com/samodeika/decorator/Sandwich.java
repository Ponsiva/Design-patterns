package com.samodeika.decorator;

public interface Sandwich {
	
	public String make();
	
}
