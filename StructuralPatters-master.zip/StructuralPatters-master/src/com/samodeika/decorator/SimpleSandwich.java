package com.samodeika.decorator;

public class SimpleSandwich implements Sandwich {

	@Override
	public String make() {
		return "Simple Sandwich - bread";
	}

}
