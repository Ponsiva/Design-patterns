package com.samodeika.bridge.shape1;

public abstract class Circle extends Shape {

}
