package com.samodeika.abstractFactory;

public class VisaGoldCreditCard extends CreditCard {
}
