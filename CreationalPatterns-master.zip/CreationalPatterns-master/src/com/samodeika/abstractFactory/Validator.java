package com.samodeika.abstractFactory;

public interface Validator {
    boolean isValid(CreditCard creditCard);
}
