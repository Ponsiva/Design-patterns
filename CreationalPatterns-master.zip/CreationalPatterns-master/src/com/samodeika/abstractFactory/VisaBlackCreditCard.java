package com.samodeika.abstractFactory;

public class VisaBlackCreditCard extends CreditCard {
}
