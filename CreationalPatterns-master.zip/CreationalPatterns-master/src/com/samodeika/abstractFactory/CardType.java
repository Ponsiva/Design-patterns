package com.samodeika.abstractFactory;

public enum CardType {
    GOLD, PLATINUM;
}
