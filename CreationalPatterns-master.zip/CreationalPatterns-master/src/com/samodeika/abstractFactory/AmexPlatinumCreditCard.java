package com.samodeika.abstractFactory;

public class AmexPlatinumCreditCard extends CreditCard {
}
