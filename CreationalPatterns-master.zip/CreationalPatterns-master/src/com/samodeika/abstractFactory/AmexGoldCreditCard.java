package com.samodeika.abstractFactory;

public class AmexGoldCreditCard extends CreditCard {
}
