package com.samodeika.factory;

/**
 * Created by Eagle on 20.10.2015 ?..
 */
public class ContactPage extends Page {

}
