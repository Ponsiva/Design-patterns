package com.samodeika.factory;

public enum WebsiteType {

    BLOG, SHOP;

}
